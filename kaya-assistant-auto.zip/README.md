# Kaya Assistant - Versi Hologram Auto JARVIS

**Dibangunkan oleh:** iCin  
**Pemilik Sistem:** Boss

Ini adalah projek eksklusif `Kaya Assistant` versi auto penuh dengan antaramuka hologram seperti J.A.R.V.I.S., suara responsif, dan animasi canggih.

## 🔧 Kandungan Utama
- `index.html` – Halaman utama
- `style.css` – Reka bentuk antaramuka
- `script.js` – Logik interaktif & suara
- `assets/` – Gambar & audio hologram

## 🚀 Status Projek
✅ UI Hologram  
✅ Suara Jordan Belfort BM+English  
✅ Shortcut Siri  
✅ Notifikasi suara

> ⚠️ **Akses peribadi Boss sahaja. Tidak dibenarkan dikongsi.**
